#!/bin/bash

# QUANTUM NEXUS - БЫСТРОЕ ВОССТАНОВЛЕНИЕ
# Автор: SmartFix
# Дата: 29.10.2025

set -e

echo "🚀 QUANTUM NEXUS - БЫСТРОЕ ВОССТАНОВЛЕНИЕ"
echo "========================================"

# Проверка прав root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Запустите скрипт с правами root: sudo ./QUICK_RESTORE.sh"
    exit 1
fi

# Переменные
PROJECT_DIR="/home/quantum-nexus/quantum-nexus"
BACKUP_DIR="$(pwd)"
DB_NAME="quantum_nexus"
DB_USER="quantum_user"
DB_PASS="$(openssl rand -base64 32)"

echo "📁 Создание директории проекта..."
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

echo "📋 Копирование файлов проекта..."
cp -r $BACKUP_DIR/* ./
chown -R quantum-nexus:quantum-nexus ./

echo "🐍 Создание виртуального окружения..."
python3 -m venv venv
source venv/bin/activate

echo "📦 Установка зависимостей..."
pip install -r requirements.txt

echo "🗄️ Настройка базы данных..."
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

echo "⚙️ Создание конфигурации..."
cat > .env << EOF
TELEGRAM_TOKEN=YOUR_BOT_TOKEN_HERE
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost/$DB_NAME
REDIS_URL=redis://localhost:6379
WEBHOOK_URL=https://yourdomain.com
WEBHOOK_SECRET=$(openssl rand -base64 32)
ADMIN_PASSWORD=$(openssl rand -base64 16)
EOF

chmod 600 .env
chown quantum-nexus:quantum-nexus .env

echo "🔧 Настройка systemd сервисов..."

# Бот сервис
cat > /etc/systemd/system/quantum-nexus-bot.service << EOF
[Unit]
Description=Quantum Nexus Telegram Bot
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=quantum-nexus
WorkingDirectory=$PROJECT_DIR
Environment=PATH=$PROJECT_DIR/venv/bin
ExecStart=$PROJECT_DIR/venv/bin/python bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Web сервис
cat > /etc/systemd/system/quantum-nexus-web.service << EOF
[Unit]
Description=Quantum Nexus Web Server
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=quantum-nexus
WorkingDirectory=$PROJECT_DIR
Environment=PATH=$PROJECT_DIR/venv/bin
ExecStart=$PROJECT_DIR/venv/bin/python web_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

echo "🔄 Перезагрузка systemd..."
systemctl daemon-reload

echo "🚀 Запуск сервисов..."
systemctl enable quantum-nexus-bot
systemctl enable quantum-nexus-web
systemctl start quantum-nexus-bot
systemctl start quantum-nexus-web

echo "⏳ Ожидание запуска сервисов..."
sleep 5

echo "📊 Проверка статуса..."
systemctl status quantum-nexus-bot --no-pager
systemctl status quantum-nexus-web --no-pager

echo ""
echo "✅ ВОССТАНОВЛЕНИЕ ЗАВЕРШЕНО!"
echo "================================"
echo "📁 Директория проекта: $PROJECT_DIR"
echo "🗄️ База данных: $DB_NAME"
echo "👤 Пользователь БД: $DB_USER"
echo "🔑 Пароль БД: $DB_PASS"
echo ""
echo "⚠️  ВАЖНО:"
echo "1. Отредактируйте файл $PROJECT_DIR/.env"
echo "2. Добавьте ваш Telegram Bot Token"
echo "3. Настройте домен для webhook"
echo "4. Перезапустите сервисы:"
echo "   sudo systemctl restart quantum-nexus-bot"
echo "   sudo systemctl restart quantum-nexus-web"
echo ""
echo "📖 Подробные инструкции: RESTORE_INSTRUCTIONS.md"
echo "🔧 Логи сервисов:"
echo "   sudo journalctl -u quantum-nexus-bot -f"
echo "   sudo journalctl -u quantum-nexus-web -f"
