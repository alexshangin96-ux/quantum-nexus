# QUANTUM NEXUS - ИНСТРУКЦИИ ПО ВОССТАНОВЛЕНИЮ

## 📋 ПРЕДВАРИТЕЛЬНЫЕ ТРЕБОВАНИЯ

### Системные требования:
- Ubuntu 20.04+ или Debian 10+
- Python 3.8+
- PostgreSQL 12+
- Redis 6+
- Nginx (опционально)
- Git

### Учетные записи:
- Telegram Bot Token
- PostgreSQL база данных
- GitHub репозиторий (опционально)

## 🚀 БЫСТРОЕ ВОССТАНОВЛЕНИЕ

### 1. Подготовка сервера
```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка зависимостей
sudo apt install -y python3 python3-pip python3-venv postgresql postgresql-contrib redis-server nginx git

# Создание пользователя для проекта
sudo useradd -m -s /bin/bash quantum-nexus
sudo usermod -aG sudo quantum-nexus
```

### 2. Копирование файлов
```bash
# Переход в домашнюю директорию
cd /home/quantum-nexus

# Копирование файлов проекта
sudo cp -r /path/to/Quantum-Nexus-Backup-2025-10-29-17-22/quantum-nexus/ ./
sudo chown -R quantum-nexus:quantum-nexus ./quantum-nexus
cd quantum-nexus
```

### 3. Настройка базы данных
```bash
# Вход в PostgreSQL
sudo -u postgres psql

# Создание базы данных и пользователя
CREATE DATABASE quantum_nexus;
CREATE USER quantum_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE quantum_nexus TO quantum_user;
\q
```

### 4. Настройка конфигурации
```bash
# Создание файла .env
cat > .env << EOF
TELEGRAM_TOKEN=your_bot_token_here
DATABASE_URL=postgresql://quantum_user:your_secure_password@localhost/quantum_nexus
REDIS_URL=redis://localhost:6379
WEBHOOK_URL=https://yourdomain.com
WEBHOOK_SECRET=your_webhook_secret
ADMIN_PASSWORD=your_admin_password
EOF

# Установка прав доступа
chmod 600 .env
```

### 5. Установка зависимостей
```bash
# Создание виртуального окружения
python3 -m venv venv
source venv/bin/activate

# Установка пакетов
pip install -r requirements.txt
```

### 6. Инициализация базы данных
```bash
# Создание таблиц
python3 -c "from database import init_db; init_db()"

# Или через Alembic (если есть миграции)
# alembic upgrade head
```

### 7. Настройка systemd сервисов

#### Бот сервис:
```bash
sudo tee /etc/systemd/system/quantum-nexus-bot.service > /dev/null << EOF
[Unit]
Description=Quantum Nexus Telegram Bot
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=quantum-nexus
WorkingDirectory=/home/quantum-nexus/quantum-nexus
Environment=PATH=/home/quantum-nexus/quantum-nexus/venv/bin
ExecStart=/home/quantum-nexus/quantum-nexus/venv/bin/python bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
```

#### Web сервер:
```bash
sudo tee /etc/systemd/system/quantum-nexus-web.service > /dev/null << EOF
[Unit]
Description=Quantum Nexus Web Server
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=quantum-nexus
WorkingDirectory=/home/quantum-nexus/quantum-nexus
Environment=PATH=/home/quantum-nexus/quantum-nexus/venv/bin
ExecStart=/home/quantum-nexus/quantum-nexus/venv/bin/python web_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
```

### 8. Настройка Nginx (опционально)
```bash
sudo tee /etc/nginx/sites-available/quantum-nexus > /dev/null << EOF
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# Активация сайта
sudo ln -s /etc/nginx/sites-available/quantum-nexus /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 9. Запуск сервисов
```bash
# Перезагрузка systemd
sudo systemctl daemon-reload

# Запуск сервисов
sudo systemctl enable quantum-nexus-bot
sudo systemctl enable quantum-nexus-web
sudo systemctl start quantum-nexus-bot
sudo systemctl start quantum-nexus-web

# Проверка статуса
sudo systemctl status quantum-nexus-bot
sudo systemctl status quantum-nexus-web
```

## 🔧 ДОПОЛНИТЕЛЬНАЯ НАСТРОЙКА

### Настройка SSL (Let's Encrypt)
```bash
# Установка Certbot
sudo apt install certbot python3-certbot-nginx

# Получение сертификата
sudo certbot --nginx -d yourdomain.com

# Автоматическое обновление
sudo crontab -e
# Добавить: 0 12 * * * /usr/bin/certbot renew --quiet
```

### Настройка мониторинга
```bash
# Установка htop для мониторинга
sudo apt install htop

# Просмотр логов
sudo journalctl -u quantum-nexus-bot -f
sudo journalctl -u quantum-nexus-web -f
```

## 🚨 УСТРАНЕНИЕ НЕПОЛАДОК

### Проблемы с базой данных
```bash
# Проверка подключения
sudo -u postgres psql -c "SELECT 1;"

# Проверка пользователя
sudo -u postgres psql -c "SELECT * FROM pg_user WHERE usename='quantum_user';"
```

### Проблемы с Redis
```bash
# Проверка Redis
redis-cli ping

# Перезапуск Redis
sudo systemctl restart redis
```

### Проблемы с ботом
```bash
# Проверка логов
sudo journalctl -u quantum-nexus-bot --since "1 hour ago"

# Перезапуск бота
sudo systemctl restart quantum-nexus-bot
```

## 📊 МОНИТОРИНГ И ОБСЛУЖИВАНИЕ

### Регулярные задачи
```bash
# Создание скрипта для бэкапа БД
sudo tee /home/quantum-nexus/backup_db.sh > /dev/null << EOF
#!/bin/bash
DATE=\$(date +%Y%m%d_%H%M%S)
pg_dump quantum_nexus > /home/quantum-nexus/backups/quantum_nexus_\$DATE.sql
find /home/quantum-nexus/backups/ -name "*.sql" -mtime +7 -delete
EOF

sudo chmod +x /home/quantum-nexus/backup_db.sh
sudo mkdir -p /home/quantum-nexus/backups

# Добавление в crontab
sudo crontab -e
# Добавить: 0 2 * * * /home/quantum-nexus/backup_db.sh
```

## ✅ ПРОВЕРКА РАБОТОСПОСОБНОСТИ

1. **Проверка бота**: Отправьте `/start` в Telegram
2. **Проверка Web App**: Откройте бота и нажмите "Играть"
3. **Проверка админки**: Перейдите на `https://yourdomain.com/admin`
4. **Проверка API**: `curl http://localhost:5000/api/health`

## 📞 ПОДДЕРЖКА

При возникновении проблем:
1. Проверьте логи сервисов
2. Убедитесь в правильности конфигурации
3. Проверьте доступность всех зависимостей
4. Обратитесь к документации проекта

---
**Дата создания бэкапа**: 29.10.2025 17:22  
**Версия проекта**: 2.0 Final  
**Автор**: SmartFix
